/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ottoalexander
 */
public class Carrera {
        private String Nombre;
	private String clase1_1, clase1_2, clase1_3, clase1_4, clase1_5, clase1_6, clase1_7;
        private String clase2_1, clase2_2, clase2_3, clase2_4, clase2_5, clase2_6;
        private String clase3_1, clase3_2, clase3_3, clase3_4, clase3_5, clase3_6;
        private String clase4_1, clase4_2, clase4_3, clase4_4, clase4_5, clase4_6;
        private String clase5_1, clase5_2, clase5_3, clase5_4, clase5_5, clase5_6;
        private String clase6_1, clase6_2, clase6_3, clase6_4, clase6_5, clase6_6;
        private String clase7_1, clase7_2, clase7_3, clase7_4, clase7_5, clase7_6;
        private String clase8_1, clase8_2, clase8_3, clase8_4, clase8_5, clase8_6;
        private String clase9_1, clase9_2, clase9_3, clase9_4, clase9_5, clase9_6;
        private String clase10_1, clase10_2, clase10_3, clase10_4, clase10_5, clase10_6;

	//Metodos
	//Constructor
	public Carrera(){
	Nombre = "";
	clase1_1 = ""; clase1_2 = ""; clase1_3 = ""; clase1_4 = "";
        clase1_5 = ""; clase1_6 = ""; clase1_7 = "";
        
        clase2_1 = ""; clase2_2 = ""; clase2_3 = ""; clase2_4 = "";
        clase2_5 = ""; clase2_6 = "";
        
        clase3_1 = ""; clase3_2 = ""; clase3_3 = ""; clase3_4 = "";
        clase3_5 = ""; clase3_6 = "";
        
        clase4_1 = "";  clase4_2 = ""; clase4_3 = ""; clase4_4 = ""; 
        clase4_5 = ""; clase4_6 = "";
        
        clase5_1 = "";  clase5_2 = ""; clase5_3 = ""; clase5_4 = ""; 
        clase5_5 = ""; clase5_6 = "";
        
        clase6_1 = "";  clase6_2 = ""; clase6_3 = ""; clase6_4 = ""; 
        clase6_5 = ""; clase6_6 = "";
               
        clase7_1 = "";  clase7_2 = ""; clase7_3 = ""; clase7_4 = ""; 
        clase7_5 = ""; clase7_6 = "";
        
        clase8_1 = "";  clase8_2 = ""; clase8_3 = ""; clase8_4 = ""; 
        clase8_5 = ""; clase8_6 = "";
        
        
        clase9_1 = "";  clase9_2 = ""; clase9_3 = ""; clase9_4 = ""; 
        clase9_5 = ""; clase9_6 = "";
        
        clase10_1 = "";  clase10_2 = ""; clase10_3 = ""; clase10_4 = ""; 
        clase10_5 = ""; clase10_6 = ""; 
	}
//Guarda el nombre de la carrea 
	public void setNombre(String nombre){
		this.Nombre = nombre;
	}
	public String getNombre(){
		return Nombre;
	}
//Guarda los cursos del primer semestre
	public void setclase1_1(String clase1_1){
		this.clase1_1 = clase1_1;}
	public String getclase1_1(){
		return clase1_1;}
	
        public void setclase1_2(String clase1_2){
		this.clase1_2 = clase1_2;}
	public String getclase1_2(){
		return clase1_2;}
        
        public void setclase1_3(String clase1_3){
		this.clase1_3 = clase1_3;}
	public String getclase1_3(){
		return clase1_3;}
        
        public void setclase1_4(String clase1_4){
		this.clase1_4 = clase1_4;}
	public String getclase1_4(){
		return clase1_4;}
        
        public void setclase1_5(String clase1_5){
		this.clase1_5 = clase1_5;}
	public String getclase1_5(){
		return clase1_5;}
 
	public void setclase1_6(String clase1_6){
		this.clase1_6 = clase1_6;}
	public String getclase1_6(){
		return clase1_6;}
        
        public void setclase1_7(String clase1_7){
		this.clase1_7 = clase1_7;}
	public String getclase1_7(){
		return clase1_7;}
        
        
//Guarda los cursos del segundo semestre
	public void setclase2_1(String clase2_1){
		this.clase2_1 = clase2_1;}
	public String getclase2_1(){
		return clase2_1;}
	
        public void setclase2_2(String clase2_2){
		this.clase2_2 = clase2_2;}
	public String getclase2_2(){
		return clase2_2;}
        
        public void setclase2_3(String clase2_3){
		this.clase2_3 = clase2_3;}
	public String getclase2_3(){
		return clase2_3;}
        
        public void setclase2_4(String clase2_4){
		this.clase2_4 = clase2_4;}
	public String getclase2_4(){
		return clase2_4;}
        
        public void setclase2_5(String clase2_5){
		this.clase2_5 = clase2_5;}
	public String getclase2_5(){
		return clase2_5;}
 
	public void setclase2_6(String clase2_6){
		this.clase2_6 = clase2_6;}
	public String getclase2_6(){
		return clase2_6;}
        
        //Guarda los cursos del tercer semestre
	public void setclase3_1(String clase3_1){
		this.clase3_1 = clase3_1;}
	public String getclase3_1(){
		return clase3_1;}
	
        public void setclase3_2(String clase3_2){
		this.clase3_2 = clase3_2;}
	public String getclase3_2(){
		return clase3_2;}
        
        public void setclase3_3(String clase3_3){
		this.clase3_3 = clase3_3;}
	public String getclase3_3(){
		return clase3_3;}
        
        public void setclase3_4(String clase3_4){
		this.clase3_4 = clase3_4;}
	public String getclase3_4(){
		return clase3_4;}
        
        public void setclase3_5(String clase3_5){
		this.clase3_5 = clase3_5;}
	public String getclase3_5(){
		return clase3_5;}
 
	public void setclase3_6(String clase3_6){
		this.clase3_6 = clase3_6;}
	public String getclase3_6(){
		return clase3_6;}
        
        //Guarda los cursos del cuatro semestre
        public void setclase4_1(String clase4_1){
		this.clase4_1 = clase4_1;}
	public String getclase4_1(){
		return clase4_1;}
	
        public void setclase4_2(String clase4_2){
		this.clase4_2 = clase4_2;}
	public String getclase4_2(){
		return clase4_2;}
        
        public void setclase4_3(String clase4_3){
		this.clase4_3 = clase4_3;}
	public String getclase4_3(){
		return clase4_3;}
        
        public void setclase4_4(String clase4_4){
		this.clase4_4 = clase4_4;}
	public String getclase4_4(){
		return clase4_4;}
        
        public void setclase4_5(String clase4_5){
		this.clase4_5 = clase4_5;}
	public String getclase4_5(){
		return clase4_5;}
 
	public void setclase4_6(String clase4_6){
		this.clase4_6 = clase4_6;}
	public String getclase4_6(){
		return clase4_6;}
                
     //Guarda los cursos del quinto semestre
       public void setclase5_1(String clase5_1){
		this.clase5_1 = clase5_1;}
	public String getclase5_1(){
		return clase5_1;}
	
        public void setclase5_2(String clase5_2){
		this.clase5_2 = clase5_2;}
	public String getclase5_2(){
		return clase5_2;}
        
        public void setclase5_3(String clase5_3){
		this.clase5_3 = clase5_3;}
	public String getclase5_3(){
		return clase5_3;}
        
        public void setclase5_4(String clase5_4){
		this.clase5_4 = clase5_4;}
	public String getclase5_4(){
		return clase5_4;}
        
        public void setclase5_5(String clase5_5){
		this.clase5_5 = clase5_5;}
	public String getclase5_5(){
		return clase5_5;}
 
	public void setclase5_6(String clase5_6){
		this.clase5_6 = clase5_6;}
	public String getclase5_6(){
		return clase5_6;}

        //Guarda los cursos del sexto semestre
        public void setclase6_1(String clase6_1){
		this.clase6_1 = clase6_1;}
	public String getclase6_1(){
		return clase6_1;}
	
        public void setclase6_2(String clase6_2){
		this.clase6_2 = clase6_2;}
	public String getclase6_2(){
		return clase6_2;}
        
        public void setclase6_3(String clase6_3){
		this.clase6_3 = clase6_3;}
	public String getclase6_3(){
		return clase6_3;}
        
        public void setclase6_4(String clase6_4){
		this.clase6_4 = clase6_4;}
	public String getclase6_4(){
		return clase6_4;}
        
        public void setclase6_5(String clase6_5){
		this.clase6_5 = clase6_5;}
	public String getclase6_5(){
		return clase6_5;}
 
	public void setclase6_6(String clase6_6){
		this.clase6_6 = clase6_6;}
	public String getclase6_6(){
		return clase6_6;}

         //Guarda los cursos del semestre semestre
        public void setclase7_1(String clase7_1){
		this.clase7_1 = clase7_1;}
	public String getclase7_1(){
		return clase7_1;}
	
        public void setclase7_2(String clase7_2){
		this.clase7_2 = clase7_2;}
	public String getclase7_2(){
		return clase7_2;}
        
        public void setclase7_3(String clase7_3){
		this.clase7_3 = clase7_3;}
	public String getclase7_3(){
		return clase7_3;}
        
        public void setclase7_4(String clase7_4){
		this.clase7_4 = clase7_4;}
	public String getclase7_4(){
		return clase7_4;}
        
        public void setclase7_5(String clase7_5){
		this.clase7_5 = clase7_5;}
	public String getclase7_5(){
		return clase7_5;}
 
	public void setclase7_6(String clase7_6){
		this.clase7_6 = clase7_6;}
	public String getclase7_6(){
		return clase7_6;}

        
        //Guarda los cursos del semestre semestre
        public void setclase8_1(String clase8_1){
		this.clase8_1 = clase8_1;}
	public String getclase8_1(){
		return clase8_1;}
	
        public void setclase8_2(String clase8_2){
		this.clase8_2 = clase8_2;}
	public String getclase8_2(){
		return clase8_2;}
        
        public void setclase8_3(String clase8_3){
		this.clase8_3 = clase8_3;}
	public String getclase8_3(){
		return clase8_3;}
        
        public void setclase8_4(String clase8_4){
		this.clase8_4 = clase8_4;}
	public String getclase8_4(){
		return clase8_4;}
        
        public void setclase8_5(String clase8_5){
		this.clase8_5 = clase8_5;}
	public String getclase8_5(){
		return clase8_5;}
 
	public void setclase8_6(String clase8_6){
		this.clase8_6 = clase8_6;}
	public String getclase8_6(){
		return clase8_6;}

        //Guarda los cursos del noveno semestre
        public void setclase9_1(String clase9_1){
		this.clase9_1 = clase9_1;}
	public String getclase9_1(){
		return clase9_1;}
	
        public void setclase9_2(String clase9_2){
		this.clase9_2 = clase9_2;}
	public String getclase9_2(){
		return clase9_2;}
        
        public void setclase9_3(String clase9_3){
		this.clase9_3 = clase9_3;}
	public String getclase9_3(){
		return clase9_3;}
        
        public void setclase9_4(String clase9_4){
		this.clase9_4 = clase9_4;}
	public String getclase9_4(){
		return clase9_4;}
        
        public void setclase9_5(String clase9_5){
		this.clase9_5 = clase9_5;}
	public String getclase9_5(){
		return clase9_5;}
 
	public void setclase9_6(String clase9_6){
		this.clase9_6 = clase9_6;}
	public String getclase9_6(){
		return clase9_6;}
        
        //Guarda los cursos del noveno semestre
        public void setclase10_1(String clase10_1){
		this.clase10_1 = clase10_1;}
	public String getclase10_1(){
		return clase10_1;}
	
        public void setclase10_2(String clase10_2){
		this.clase10_2 = clase10_2;}
	public String getclase10_2(){
		return clase10_2;}
        
        public void setclase10_3(String clase10_3){
		this.clase10_3 = clase10_3;}
	public String getclase10_3(){
		return clase10_3;}
        
        public void setclase10_4(String clase10_4){
		this.clase10_4 = clase10_4;}
	public String getclase10_4(){
		return clase10_4;}
        
        public void setclase10_5(String clase10_5){
		this.clase10_5 = clase10_5;}
	public String getclase10_5(){
		return clase10_5;}
 
	public void setclase10_6(String clase10_6){
		this.clase10_6 = clase10_6;}
	public String getclase10_6(){
		return clase10_6;}
        
        


	//toString
	public String toString(){
		return Nombre +" Clases del primer semestre:\n"+
                "-"+clase1_1+"\n-"+clase1_2+"\n-"+clase1_3+"\n-"+clase1_4+
                "\n-"+clase1_5+"\n-"+clase1_6+"\n-"+clase1_7+
                "\n\nClases del Segundo semestre:\n"+
                "-"+clase2_1+"\n-"+clase2_2+"\n-"+clase2_3+"\n-"+clase2_4+
                "\n-"+clase2_5+"\n-"+clase2_6+
                "\n\nClases del Tercer semestre:\n"+
                "-"+clase3_1+"\n-"+clase3_2+"\n-"+clase3_3+"\n-"+clase3_4+
                "\n-"+clase3_5+"\n-"+clase3_6+
                "\n\nClases del Cuarto semestre:\n"+
                "-"+clase4_1+"\n-"+clase4_2+"\n-"+clase4_3+"\n-"+clase4_4+
                "\n-"+clase4_5+"\n-"+clase4_6+
                "\n\nClases del Quinto semestre:\n"+
                "-"+clase5_1+"\n-"+clase5_2+"\n-"+clase5_3+"\n-"+clase5_4+
                "\n-"+clase5_5+"\n-"+clase5_6+
                "\n\nClases del Sexto semestre:\n"+
                "-"+clase6_1+"\n-"+clase6_2+"\n-"+clase6_3+"\n-"+clase6_4+
                "\n-"+clase6_5+"\n-"+clase6_6+
                "\n\nClases del Septimo semestre:\n"+
                "-"+clase7_1+"\n-"+clase7_2+"\n-"+clase7_3+"\n-"+clase7_4+
                "\n-"+clase7_5+"\n-"+clase7_6+
                "\n\nClases del octavo semestre:\n"+
                "-"+clase8_1+"\n-"+clase8_2+"\n-"+clase8_3+"\n-"+clase8_4+
                "\n-"+clase8_5+"\n-"+clase8_6+
                 "\n\nClases del noveno semestre:\n"+
                "-"+clase9_1+"\n-"+clase9_2+"\n-"+clase9_3+"\n-"+clase9_4+
                "\n-"+clase9_5+"\n-"+clase9_6+
                "\n\nClases del Decimo semestre:\n"+
                "-"+clase10_1+"\n-"+clase10_2+"\n-"+clase10_3+"\n-"+clase10_4+
                "\n-"+clase10_5+"\n-"+clase10_6;}
    
}
